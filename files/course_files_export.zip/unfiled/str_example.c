#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define STR_LEN 100
#define NUM_STR 5

void main(void){
    int i;
    char str1[STR_LEN];
    
    str1 = "Hello CprE 308";          //always bad
    printf("str1: %s\n", str1);
    strcpy(str1, "Hello CprE 308");   //good
    printf("str1: %s\n", str1);
    
    for(i=0; i<26; i++){
        str1[i] = 'a'+i;
    }
    str1[i] = '\0';
    printf("str1: %s\n", str1);
    
    
    /******************************************************/
    
    char** str2;                      //usually bad
    char*  str3[NUM_STR];             //good but have to malloc/free
    char   str4[NUM_STR][STR_LEN];    //good
    
    strcpy(str4[0], "Hello");
    strcpy(str4[1], "World");
    printf("str4: %s %s\n", str4[0], str4[1]);
    
    
    //allocate memory and assign it a value
    for(i=0; i<NUM_STR; i++){
        str3[i] = (char*)malloc( sizeof(char)*STR_LEN);
        strcpy(str3[i], "308");
    }
    
    //print str3
    printf("str3: ");
    for(i=0; i<NUM_STR; i++){
        printf("%s ", str3[i]);
    }
    printf("\n");
    
    
    //free memory from heap.
    for(i=0; i<NUM_STR; i++){
        free(str3[i]);
    }
    
}